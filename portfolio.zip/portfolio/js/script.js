// Scroll suave para âncoras do menu
document.querySelectorAll('nav a[href^="#"]').forEach(link => {
    link.addEventListener('click', function(e) {
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            e.preventDefault();
            target.scrollIntoView({ behavior: 'smooth' });
        }
    });
});

// Botão "voltar ao topo"
const btnTopo = document.getElementById('btn-topo');
window.addEventListener('scroll', () => {
    if (window.scrollY > 300) {
        btnTopo.style.display = 'block';
    } else {
        btnTopo.style.display = 'none';
    }
});
btnTopo.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
});

// Skill cards interativos (efeito animado ao clicar)
const skillCards = document.querySelectorAll('.skill-card');
skillCards.forEach(card => {
    card.addEventListener('click', () => {
        skillCards.forEach(c => c.classList.remove('active'));
        card.classList.add('active');
        setTimeout(() => card.classList.remove('active'), 900);
    });
});